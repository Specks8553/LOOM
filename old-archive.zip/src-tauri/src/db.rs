use rusqlite::Connection;

use crate::error::LoomError;

/// Open a SQLCipher-encrypted world database.
pub fn open_world_db(db_path: &std::path::Path, key: &[u8; 32]) -> Result<Connection, LoomError> {
    let conn = Connection::open(db_path)?;

    // Set the encryption key via PRAGMA
    let key_hex = hex::encode(key);
    conn.execute_batch(&format!("PRAGMA key = \"x'{key_hex}'\";"))?;

    // Verify the connection works by reading the schema
    conn.execute_batch("SELECT count(*) FROM sqlite_master;")?;

    // Run dev-phase migrations for schema changes
    migrate_dev_schema(&conn)?;

    Ok(conn)
}

/// Initialize the full database schema for a new world.
/// Creates all 9+2 tables per Doc 15 §7.
pub fn init_schema(conn: &Connection) -> Result<(), LoomError> {
    conn.execute_batch(
        "
        -- Vault tree nodes (stories, folders, docs, images)
        CREATE TABLE IF NOT EXISTS items (
            id           TEXT PRIMARY KEY,
            story_id     TEXT,
            parent_id    TEXT REFERENCES items(id) ON DELETE SET NULL,
            item_type    TEXT NOT NULL CHECK(item_type IN ('Story','Folder','SourceDocument','Image')),
            item_subtype TEXT,
            name         TEXT NOT NULL,
            content      TEXT NOT NULL DEFAULT '',
            description  TEXT,
            sort_order   INTEGER NOT NULL DEFAULT 0,
            created_at   TEXT NOT NULL,
            modified_at  TEXT NOT NULL,
            deleted_at   TEXT,
            asset_path   TEXT,
            asset_meta   TEXT,
            file_api_uri TEXT,
            file_api_uploaded_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_items_parent  ON items(parent_id);
        CREATE INDEX IF NOT EXISTS idx_items_type    ON items(item_type);
        CREATE INDEX IF NOT EXISTS idx_items_deleted ON items(deleted_at);

        -- Conversation messages (DAG structure) — Doc 09 §1.1
        CREATE TABLE IF NOT EXISTS messages (
            id                  TEXT PRIMARY KEY,
            story_id            TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            parent_id           TEXT REFERENCES messages(id) ON DELETE SET NULL,
            role                TEXT NOT NULL CHECK(role IN ('user','model')),
            content_type        TEXT NOT NULL DEFAULT 'text'
                                  CHECK(content_type IN ('json_user','text','blocks')),
            content             TEXT NOT NULL DEFAULT '',
            token_count         INTEGER,
            model_name          TEXT,
            finish_reason       TEXT CHECK(finish_reason IN ('STOP','MAX_TOKENS','SAFETY','ERROR') OR finish_reason IS NULL),
            created_at          TEXT NOT NULL,
            deleted_at          TEXT,
            user_feedback       TEXT,
            ghostwriter_history TEXT NOT NULL DEFAULT '[]'
        );
        CREATE INDEX IF NOT EXISTS idx_messages_story  ON messages(story_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_messages_parent ON messages(parent_id);

        -- Per-story key-value settings
        CREATE TABLE IF NOT EXISTS story_settings (
            story_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            key      TEXT NOT NULL,
            value    TEXT NOT NULL DEFAULT '',
            PRIMARY KEY (story_id, key)
        );

        -- Branch checkpoints (used by Branch Map + Accordion) — Doc 17 §7.1
        CREATE TABLE IF NOT EXISTS checkpoints (
            id               TEXT PRIMARY KEY,
            story_id         TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            after_message_id TEXT REFERENCES messages(id) ON DELETE SET NULL,
            name             TEXT NOT NULL DEFAULT 'Checkpoint',
            is_start         INTEGER NOT NULL DEFAULT 0,
            created_at       TEXT NOT NULL,
            modified_at      TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_checkpoints_story ON checkpoints(story_id);
        CREATE INDEX IF NOT EXISTS idx_checkpoints_after_msg ON checkpoints(after_message_id);

        -- Accordion segment summaries — Doc 18 §11
        CREATE TABLE IF NOT EXISTS accordion_segments (
            id              TEXT PRIMARY KEY,
            story_id        TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            start_cp_id     TEXT NOT NULL REFERENCES checkpoints(id) ON DELETE CASCADE,
            end_cp_id       TEXT NOT NULL REFERENCES checkpoints(id) ON DELETE CASCADE,
            summary         TEXT,
            is_collapsed    INTEGER NOT NULL DEFAULT 0,
            is_stale        INTEGER NOT NULL DEFAULT 0,
            branch_leaf_id  TEXT,
            summarised_at   TEXT,
            created_at      TEXT NOT NULL,
            modified_at     TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_accordion_story    ON accordion_segments(story_id);
        CREATE INDEX IF NOT EXISTS idx_accordion_end_cp   ON accordion_segments(end_cp_id);
        CREATE INDEX IF NOT EXISTS idx_accordion_branch   ON accordion_segments(branch_leaf_id);

        -- User-defined Source Document templates
        CREATE TABLE IF NOT EXISTS templates (
            id              TEXT PRIMARY KEY,
            slug            TEXT NOT NULL UNIQUE,
            name            TEXT NOT NULL,
            icon            TEXT NOT NULL DEFAULT 'FileText',
            default_content TEXT NOT NULL DEFAULT '',
            is_builtin      INTEGER NOT NULL DEFAULT 0,
            sort_order      INTEGER NOT NULL DEFAULT 0,
            created_at      TEXT NOT NULL,
            modified_at     TEXT NOT NULL
        );

        -- World-level key-value settings
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );

        -- Rate limiter counters (3 rows: text, image_gen, tts)
        CREATE TABLE IF NOT EXISTS telemetry (
            provider       TEXT PRIMARY KEY,
            req_count_min  INTEGER NOT NULL DEFAULT 0,
            req_count_day  INTEGER NOT NULL DEFAULT 0,
            token_count_min INTEGER NOT NULL DEFAULT 0,
            last_req_at    TEXT,
            window_start_min TEXT,
            window_start_day TEXT
        );

        -- Doc attachment/detach audit trail
        CREATE TABLE IF NOT EXISTS attachment_history (
            id          TEXT PRIMARY KEY,
            story_id    TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            doc_id      TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            action      TEXT NOT NULL CHECK(action IN ('attach','detach')),
            created_at  TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_attachment_story ON attachment_history(story_id);
        "
    )?;

    Ok(())
}

/// Seed the settings table with all default values per Doc 05 §11.
pub fn seed_default_settings(conn: &Connection) -> Result<(), LoomError> {
    let defaults = vec![
        ("system_instructions", ""),
        ("text_model_name", "gemini-2.5-flash"),
        ("text_model_options", r#"["gemini-2.5-flash","gemini-2.5-pro","gemini-2.0-flash"]"#),
        ("accent_color", "#7c3aed"),
        ("body_font", "serif"),
        ("bubble_user_color", ""),
        ("bubble_ai_color", "#1a1a1a"),
        ("ghostwriter_frame_color", ""),
        ("ghostwriter_diff_color", ""),
        ("checkpoint_color", ""),
        ("accordion_color", ""),
        ("rate_limit_rpm", "10"),
        ("rate_limit_tpm", "250000"),
        ("rate_limit_rpd", "1500"),
        ("context_token_limit", "128000"),
        ("modificator_presets", "[]"),
        ("last_open_story_id", ""),
        ("img_gen_model_name", ""),
        ("tts_model_name", ""),
        ("system_instructions_2", ""),
        ("si_slot_1_name", "SI 1"),
        ("si_slot_2_name", "SI 2"),
        ("active_si_slot", "1"),
        ("prompt_ghostwriter", "You are a ghostwriter assisting a writer with targeted revisions to story text.\n\nYou will receive a revision request containing three tagged sections:\n\n<context_before>: Text from the same AI response that immediately precedes the selection. Do NOT include this in your output.\n<selected_passage>: The text to revise. This is the ONLY part you rewrite.\n<context_after>: Text from the same AI response that immediately follows the selection. Do NOT include this in your output.\n\nRules:\n1. Rewrite ONLY the selected passage according to the writer's instruction.\n2. Match the tone, voice, and style of the surrounding context.\n3. Preserve paragraph structure unless the instruction explicitly asks to change it.\n4. Return ONLY the revised passage — no tags, no preamble, no commentary, no surrounding text."),
        ("prompt_accordion_summarise", "Summarize the following conversation segment concisely. Capture the key plot points, character developments, and world-building details. Focus on information that would be needed to continue the story coherently."),
        ("prompt_accordion_fake_user", "Summarize this chapter: actions, character states, and world state at the end of the chapter."),
    ];

    let mut stmt = conn.prepare(
        "INSERT OR IGNORE INTO settings (key, value) VALUES (?1, ?2)"
    )?;

    for (key, value) in defaults {
        stmt.execute(rusqlite::params![key, value])?;
    }

    Ok(())
}

/// Seed the telemetry table with 3 provider rows.
pub fn seed_telemetry(conn: &Connection) -> Result<(), LoomError> {
    let providers = ["text", "image_gen", "tts"];

    let mut stmt = conn.prepare(
        "INSERT OR IGNORE INTO telemetry (provider) VALUES (?1)"
    )?;

    for provider in &providers {
        stmt.execute(rusqlite::params![provider])?;
    }

    Ok(())
}

/// Seed built-in templates.
pub fn seed_builtin_templates(conn: &Connection) -> Result<(), LoomError> {
    let now = chrono::Utc::now().to_rfc3339();

    let builtins = vec![
        ("image", "Image", "Image", ""),
        ("character_profile", "Character Profile", "User", "# {{Character Name}}\n\n## Role\n{{Protagonist / Antagonist / Supporting / ...}}\n\n## Appearance\n{{Physical description, distinctive features}}\n\n## Personality\n{{Core traits, quirks, habits}}\n\n## Backstory\n{{Key events that shaped this character}}\n\n## Motivations\n{{What drives them? What do they fear?}}\n\n## Relationships\n{{Key connections to other characters}}\n\n## Voice\n{{How they speak — formal, slang, accent, verbal tics}}\n\n## Notes\n{{Anything else relevant}}"),
        ("world_building", "World Building", "Globe", "# {{World / Setting Name}}\n\n## Overview\n{{Brief description of the world or setting}}\n\n## Geography\n{{Key locations, climate, terrain}}\n\n## History\n{{Major historical events, eras, conflicts}}\n\n## Society & Culture\n{{Social structure, customs, beliefs, taboos}}\n\n## Magic / Technology\n{{Rules, limitations, how it shapes daily life}}\n\n## Factions & Power\n{{Who holds power? Key organisations, governments}}\n\n## Economy\n{{Currency, trade, resources}}\n\n## Notes\n{{Anything else relevant}}"),
    ];

    let mut stmt = conn.prepare(
        "INSERT OR IGNORE INTO templates (id, slug, name, icon, default_content, is_builtin, sort_order, created_at, modified_at)
         VALUES (?1, ?2, ?3, ?4, ?5, 1, ?6, ?7, ?8)"
    )?;

    for (i, (slug, name, icon, content)) in builtins.iter().enumerate() {
        stmt.execute(rusqlite::params![
            uuid::Uuid::new_v4().to_string(),
            slug,
            name,
            icon,
            content,
            i as i32,
            &now,
            &now,
        ])?;
    }

    Ok(())
}

/// Run development-phase schema migrations.
/// Drops and recreates tables whose schema has changed since prior phases.
/// Safe to call on every open — only acts if the old schema is detected.
pub fn migrate_dev_schema(conn: &Connection) -> Result<(), LoomError> {
    // Check if messages table has the old content_type constraint (Phase 4 schema had 'text','image')
    let table_sql: Option<String> = conn
        .query_row(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='messages'",
            [],
            |row| row.get(0),
        )
        .ok();

    if let Some(sql) = table_sql {
        if sql.contains("'image'") || !sql.contains("'json_user'") {
            // Old schema — drop and let init_schema recreate it
            // Messages table should be empty at this development stage
            log::info!("Migrating messages table to Phase 6 schema");
            conn.execute_batch(
                "DROP TABLE IF EXISTS messages;
                 DROP TABLE IF EXISTS story_settings;"
            )?;
            conn.execute_batch(
                "CREATE TABLE IF NOT EXISTS messages (
                    id                  TEXT PRIMARY KEY,
                    story_id            TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
                    parent_id           TEXT REFERENCES messages(id) ON DELETE SET NULL,
                    role                TEXT NOT NULL CHECK(role IN ('user','model')),
                    content_type        TEXT NOT NULL DEFAULT 'text'
                                          CHECK(content_type IN ('json_user','text','blocks')),
                    content             TEXT NOT NULL DEFAULT '',
                    token_count         INTEGER,
                    model_name          TEXT,
                    finish_reason       TEXT CHECK(finish_reason IN ('STOP','MAX_TOKENS','SAFETY','ERROR') OR finish_reason IS NULL),
                    created_at          TEXT NOT NULL,
                    deleted_at          TEXT,
                    user_feedback       TEXT,
                    ghostwriter_history TEXT NOT NULL DEFAULT '[]'
                );
                CREATE INDEX IF NOT EXISTS idx_messages_story  ON messages(story_id, created_at);
                CREATE INDEX IF NOT EXISTS idx_messages_parent ON messages(parent_id);
                CREATE TABLE IF NOT EXISTS story_settings (
                    story_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
                    key      TEXT NOT NULL,
                    value    TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (story_id, key)
                );"
            )?;
        }
    }

    // Add sort_order column to templates table if missing (Phase 11).
    // Guard: table may not exist yet on a fresh DB opened before init_schema (onboarding).
    let templates_exists: bool = conn
        .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='templates'")
        .and_then(|mut stmt| stmt.query_row([], |_| Ok(true)))
        .unwrap_or(false);
    if templates_exists {
        let has_sort_order: bool = conn
            .prepare("SELECT sort_order FROM templates LIMIT 1")
            .is_ok();
        if !has_sort_order {
            log::info!("Migrating templates table: adding sort_order column");
            conn.execute_batch(
                "ALTER TABLE templates ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0;"
            )?;
        }
    }

    // Fix outdated model name from earlier phases (guard: settings table may not exist yet)
    let settings_exists: bool = conn
        .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='settings'")
        .and_then(|mut stmt| stmt.query_row([], |_| Ok(true)))
        .unwrap_or(false);
    if settings_exists {
        conn.execute(
            "UPDATE settings SET value = 'gemini-2.5-flash' WHERE key = 'text_model_name' AND value = 'gemini-2.5-flash-preview'",
            [],
        ).ok();
        conn.execute(
            "UPDATE settings SET value = ?1 WHERE key = 'text_model_options' AND value LIKE '%flash-preview%'",
            rusqlite::params![r#"["gemini-2.5-flash","gemini-2.5-pro","gemini-2.0-flash"]"#],
        ).ok();
    }

    // Migrate checkpoints table to Phase 13 schema (Doc 17 §7.1)
    let cp_exists: bool = conn
        .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='checkpoints'")
        .and_then(|mut stmt| stmt.query_row([], |_| Ok(true)))
        .unwrap_or(false);
    if cp_exists {
        let cp_sql: Option<String> = conn
            .query_row(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='checkpoints'",
                [],
                |row| row.get(0),
            )
            .ok();
        if let Some(sql) = cp_sql {
            if sql.contains("message_id") || !sql.contains("after_message_id") {
                log::info!("Migrating checkpoints table to Phase 13 schema");
                conn.execute_batch(
                    "DROP TABLE IF EXISTS checkpoints;
                     CREATE TABLE IF NOT EXISTS checkpoints (
                         id               TEXT PRIMARY KEY,
                         story_id         TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
                         after_message_id TEXT REFERENCES messages(id) ON DELETE SET NULL,
                         name             TEXT NOT NULL DEFAULT 'Checkpoint',
                         is_start         INTEGER NOT NULL DEFAULT 0,
                         created_at       TEXT NOT NULL,
                         modified_at      TEXT NOT NULL
                     );
                     CREATE INDEX IF NOT EXISTS idx_checkpoints_story ON checkpoints(story_id);
                     CREATE INDEX IF NOT EXISTS idx_checkpoints_after_msg ON checkpoints(after_message_id);"
                )?;
            }
        }
    }

    // ── Accordion segments migration (Phase 14: old schema used start_msg_id/end_msg_id) ──
    let as_exists = conn
        .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='accordion_segments'")
        .and_then(|mut stmt| stmt.query_row([], |_| Ok(true)))
        .unwrap_or(false);
    if as_exists {
        let as_sql: Option<String> = conn
            .query_row(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='accordion_segments'",
                [],
                |row| row.get(0),
            )
            .ok();
        if let Some(sql) = as_sql {
            if sql.contains("start_msg_id") || !sql.contains("start_cp_id") {
                log::info!("Migrating accordion_segments table to Phase 14 (Doc 18 §11) schema");
                conn.execute_batch(
                    "DROP TABLE IF EXISTS accordion_segments;
                     CREATE TABLE IF NOT EXISTS accordion_segments (
                         id              TEXT PRIMARY KEY,
                         story_id        TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
                         start_cp_id     TEXT NOT NULL REFERENCES checkpoints(id) ON DELETE CASCADE,
                         end_cp_id       TEXT NOT NULL REFERENCES checkpoints(id) ON DELETE CASCADE,
                         summary         TEXT,
                         is_collapsed    INTEGER NOT NULL DEFAULT 0,
                         is_stale        INTEGER NOT NULL DEFAULT 0,
                         branch_leaf_id  TEXT,
                         summarised_at   TEXT,
                         created_at      TEXT NOT NULL,
                         modified_at     TEXT NOT NULL
                     );
                     CREATE INDEX IF NOT EXISTS idx_accordion_story    ON accordion_segments(story_id);
                     CREATE INDEX IF NOT EXISTS idx_accordion_end_cp   ON accordion_segments(end_cp_id);
                     CREATE INDEX IF NOT EXISTS idx_accordion_branch   ON accordion_segments(branch_leaf_id);"
                )?;
            }
        }
    }

    // Phase 15: Add image asset columns to items table
    let has_asset_path = conn
        .prepare("SELECT asset_path FROM items LIMIT 1")
        .is_ok();
    if !has_asset_path {
        log::info!("Migrating items table: adding image asset columns (Phase 15)");
        conn.execute_batch(
            "ALTER TABLE items ADD COLUMN asset_path TEXT;
             ALTER TABLE items ADD COLUMN asset_meta TEXT;
             ALTER TABLE items ADD COLUMN file_api_uri TEXT;
             ALTER TABLE items ADD COLUMN file_api_uploaded_at TEXT;"
        )?;
    }

    Ok(())
}

/// Close a database connection.
pub fn close_db(conn: Connection) {
    // Connection is dropped, which closes it
    drop(conn);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn in_memory_db() -> Connection {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        conn
    }

    #[test]
    fn test_init_schema_creates_all_tables() {
        let conn = in_memory_db();
        let tables: Vec<String> = conn
            .prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
            .unwrap()
            .query_map([], |row| row.get(0))
            .unwrap()
            .filter_map(|r| r.ok())
            .collect();

        let expected = vec![
            "accordion_segments",
            "attachment_history",
            "checkpoints",
            "items",
            "messages",
            "settings",
            "story_settings",
            "telemetry",
            "templates",
        ];
        assert_eq!(tables, expected);
    }

    #[test]
    fn test_seed_default_settings() {
        let conn = in_memory_db();
        seed_default_settings(&conn).unwrap();

        let count: i64 = conn
            .query_row("SELECT COUNT(*) FROM settings", [], |row| row.get(0))
            .unwrap();
        assert!(count >= 20, "Expected at least 20 default settings, got {}", count);

        let model: String = conn
            .query_row(
                "SELECT value FROM settings WHERE key = 'text_model_name'",
                [],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(model, "gemini-2.5-flash");
    }

    #[test]
    fn test_seed_telemetry() {
        let conn = in_memory_db();
        seed_telemetry(&conn).unwrap();

        let count: i64 = conn
            .query_row("SELECT COUNT(*) FROM telemetry", [], |row| row.get(0))
            .unwrap();
        assert_eq!(count, 3);
    }
}
